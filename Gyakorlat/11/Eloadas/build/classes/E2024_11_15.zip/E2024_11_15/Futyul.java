/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package E2024_11_15;

/**
 *
 * @author Tiba Attila
 */
public interface Futyul {
    
    public static final int db=10;
    
    public  String futtttyul();
    
    
}
